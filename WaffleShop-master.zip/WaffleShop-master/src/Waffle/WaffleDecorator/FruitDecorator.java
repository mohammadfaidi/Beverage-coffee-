package Waffle.WaffleDecorator;

import Waffle.Waffle;

public abstract class FruitDecorator extends Waffle{
    public abstract String getDescription();
}
