package Waffle.WaffleDecorator;

import Waffle.Waffle;

public abstract class CondimentDecorator extends Waffle{
    public abstract String getDescription();
}
