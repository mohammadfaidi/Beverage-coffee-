package Waffle.WaffleDecorator;
import Waffle.Waffle;

public abstract class ChocolateDecorator extends Waffle{
    public abstract String getDescription();
}
