package Beverage;

public interface Beverage {
    public String getDescription();
    public double cost();
    public void prepareBeverage();
}
